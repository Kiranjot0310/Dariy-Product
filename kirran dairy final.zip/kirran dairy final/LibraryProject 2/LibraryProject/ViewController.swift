//
//  ViewController.swift
//  LibraryProject
//
//  Created by Kiran Hans on 11/7/17.
//  Copyright © 2017 Kiran Hans. All rights reserved.
//

import UIKit

class ViewController: UIViewController ,UITextFieldDelegate{

    
    @IBOutlet weak var uname: UITextField!
    @IBOutlet weak var pass: UITextField!
    @IBAction func loginButton(_ sender: UIButton) {
        if(uname.text!=="" || pass.text!==""){
            
            let alert = UIAlertController(title: "Error Message", message: "All Fields are required", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
        }else{
            let libu=MyVariable.libuname
            let libp=MyVariable.libpass
            var cindex=""
            
            for i in 0..<libu.count{
                if(libu[i]==uname.text!){
                    cindex=String(i)
                    break
                }
            }
            if(cindex==""){
                print("Username is Wrong")
            }else{
                let cpindex=Int(cindex)
                if(libp[cpindex!]==pass.text!){
                    let libh:UIViewController = (self.storyboard?.instantiateViewController(withIdentifier: "homelib") as? LibraryHome)!
                    self.navigationController?.pushViewController(libh, animated: true)
                }else{
                    print("Password is wrong")
                }
            }
            
            
        }
    
    }
    @IBAction func resetButton(_ sender: UIButton) {
        uname.text=""
        pass.text=""
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        if(MyVariable.check=="0"){
            MyVariable.check="1"
        MyVariable.bookname=["The Scret Power","Tom and jerry","Java","c++","Medona","The Worrior"]
        MyVariable.bookpublish=["1994","1995","1992","1994","2000","2010"]
        MyVariable.category=["Fiction Books","Animated","Programming language","Autobiography"]
        MyVariable.rack=["R1","R2","R3"]
        MyVariable.bookcat=["0","0","1","2","3","4"]
        MyVariable.bookrack=["0","1","0","2","2","1"]

        MyVariable.fname=["Anuj","Puneet","Priya"]
        MyVariable.fnumb=["9988776655","6477104192","6475619988"]
        MyVariable.fid=["e1","e2","e3"]
        
        MyVariable.sname=["Kiran","Komal","gaurav"]
        MyVariable.snumb=["9000779845","6499886655","976543218"]
        MyVariable.sid=["s1","s2","s3"]
        
        MyVariable.libname=["Rohit","Abhishek"]
        MyVariable.libuname=["Lyu4","L987"]
        MyVariable.libpass=["123","234"]
        
        MyVariable.fine=["20","10","13","5"]
        MyVariable.finestatus=["1","0","0","1"]
        MyVariable.fineperson=["0","0","1","1"]
        MyVariable.finepersontype=["0","1","1","1"]
            
    }
        self.uname.delegate=self
        self.pass.delegate=self
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        self.view.endEditing(true)
        return true
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

