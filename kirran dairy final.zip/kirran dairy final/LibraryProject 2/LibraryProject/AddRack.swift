//
//  addfine.swift
//  LibraryProject
//
//  Created by Kiran Hans on 11/7/17.
//  Copyright © 2017 Kiran Hans. All rights reserved.
//

import Foundation
import UIKit

class addRack: UIViewController,UITextFieldDelegate {
    
    
    @IBOutlet weak var rackname: UITextField!
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        self.view.endEditing(true)
        return true
    }
    @IBAction func addrackbutton(_ sender: UIButton) {
        if(rackname.text!==""){
            let alert = UIAlertController(title: "Please Enter Rack No", message: "Data Added", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }else{
            MyVariable.rack.append(rackname.text!)
            let alert = UIAlertController(title: "Rack No Has been Added", message: "Data Added", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    @IBAction func reset(_ sender: UIButton) {
        rackname.text=""
    
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.rackname.delegate=self
    }
}
