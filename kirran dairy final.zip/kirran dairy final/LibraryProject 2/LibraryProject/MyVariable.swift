//
//  MyVariable.swift
//  LibraryProject
//
//  Created by Kiran Hans on 11/7/17.
//  Copyright © 2017 Kiran Hans. All rights reserved.
//

import Foundation
class MyVariable {
    static var bookname=[String]()
    static var bookcat=[String]()
    static var bookrack=[String]()
    static var bookpublish=[String]()
    static var category=[String]()
    static var rack=[String]()
    
    static var fname=[String]()
    static var fnumb=[String]()
    static var fid=[String]()
    
    static var bookgiven=[String]()
    static var date=[String]()
    static var bookperson=[String]()
    static var bookpersontype=[String]()
    
    
    
    static var sname=[String]()
    static var snumb=[String]()
    static var sid=[String]()
    
    static var libuname=[String]()
    static var libpass=[String]()
    static var libname=[String]()
    
    static var fine=[String]()
    static var finestatus=[String]()
    static var fineperson=[String]()
    static var finepersontype=[String]()
    
    static var check="0"
}

