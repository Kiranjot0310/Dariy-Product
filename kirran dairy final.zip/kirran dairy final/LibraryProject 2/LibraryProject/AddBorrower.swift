//
//  AddBorrower.swift
//  LibraryProject
//
//  Created by Kiran Hans on 11/7/17.
//  Copyright © 2017 Kiran Hans. All rights reserved.
//

import Foundation
import UIKit

class AddBorrower: UIViewController , UIPickerViewDataSource,UIPickerViewDelegate , UITextFieldDelegate{
    
    @IBOutlet weak var typedrop: UIPickerView!
    @IBOutlet weak var dropdown: UIPickerView!
    @IBOutlet weak var usertype: UITextField!
    @IBOutlet weak var uid: UITextField!
    var bookmenu=MyVariable.bookname
    var typemenu=["Faculty","Student"]
    @IBOutlet weak var username: UITextField!
    
    @IBAction func search(_ sender: UIButton) {
        
        var index=""
        
        if(usertype.text!=="" || username.text!==""){
            let alert = UIAlertController(title: "Erroe message", message: "All fields are required", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        }else{
            if(usertype.text!=="Faculty"){
                var fname=MyVariable.fid
                for i in 0..<fname.count{
                    if(fname[i]==username.text!){
                        index=String(i)
                    }
                }
            }else if(usertype.text!=="Student"){
                var fname=MyVariable.sid
                for i in 0..<fname.count{
                    if(fname[i]==username.text!){
                        index=String(i)
                    }
                }
            }
            if(index == ""){
                let alert = UIAlertController(title: "Erroe message", message: "User does not exist so can not issue book", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                uid.text!=""
            }else{
                var cindex=Int(index)
                if(usertype.text!=="Faculty"){
                    uid.text=MyVariable.fname[cindex!]
                }else if(usertype.text!=="Student"){
                    uid.text=MyVariable.sname[cindex!]
                }
            }
            
            
        }
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        self.view.endEditing(true)
        return true
    }
    @IBAction func give(_ sender: UIButton) {
        if(usertype.text!=="" || username.text!=="" || uid.text!=="" || bookname.text!==""){
            let alert = UIAlertController(title: "Erroe message", message: "All fields are required", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        }else{
            var userid=[String]()
            var userstatus=""
            if(usertype.text!=="Faculty"){
                userid=MyVariable.fid
                userstatus="0"
            }else if(usertype.text!=="Student"){
                userid=MyVariable.sid
                userstatus="1"
            }
            
            let index = userid.index(of: username.text!)
            let indexr = bookmenu.index(of: bookname.text!)
            let useridInt=String(describing: index!)
            let bookidInt=String(describing: indexr!)
           
            MyVariable.bookgiven.append(bookidInt)
            MyVariable.bookperson.append(useridInt)
            MyVariable.bookpersontype.append(userstatus)
            let alert = UIAlertController(title: "Successfully", message: "Data added", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            
            
        }
    }
    @IBOutlet weak var bookname: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
 
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    public func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
        
        if(pickerView==dropdown){
            return bookmenu.count
        }else if(pickerView==typedrop){
            return typemenu.count
        }
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if(pickerView==dropdown){
            return bookmenu[row]
        }else if(pickerView==typedrop){
            return typemenu[row]
        }
        return ""
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if(pickerView==dropdown){
            self.bookname.text = self.bookmenu[row]
            self.bookname.endEditing(true)
        }else if(pickerView==typedrop){
            self.usertype.text = self.typemenu[row]
            self.usertype.endEditing(true)
        }
        
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == self.bookname {
            self.dropdown.isHidden = true
        }
        if textField == self.usertype {
            self.typedrop.isHidden = true
        }
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == self.bookname {
            return false;
        }
        if textField == self.usertype {
            return false;
        }
        return true;
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        if textField == self.bookname{
            self.dropdown.isHidden = false
            //if you dont want the users to se the
        }
        if textField == self.usertype {
            self.typedrop.isHidden = false
            //if you dont want the users to se the
        }
    }
    
    @IBAction func resetbutton(_ sender: UIButton) {
        username.text=""
        uid.text=""
        usertype.text=""
        bookname.text=""
    }
}
