//
//  Restpin.swift
//  DairyFinal
//
//  Created by Kiran Hans on 11/11/17.
//  Copyright © 2017 Kiran Hans. All rights reserved.
//

import Foundation
