//
//  MyVar.swift
//  DairyFinal
//
//  Created by Kiran Hans on 11/10/17.
//  Copyright © 2017 Kiran Hans. All rights reserved.
//

import Foundation
class MyVar{
    static var name=[String]()
    static var pass=[String]()
    static var mobile=[String]()
    static var email=[String]()
    
    static var statusLogin=0
    static var myorder=[String]()
    static var myOrderPrice=[String]()
    static var checkStatus=0
    static var dairy=0
    static var hansP=["Butter", "Pudding", "Infant Milk Powder" , "Milk Cake" ,"Yogurt" ,"Pasteurized  Milk",]
    static var hanscost=["5.78", "20","9.7" , "6.4","17" ,"12"]
    
    static var onP=["Sterilized Flovored Milk", "Whole Milk Powder", "Cheese", "Butter", "Pudding", "Infant Milk Powder"]
    static var oncost=["10.35", "9.9", "8.9", "5.78", "20","9.7"]
    
    
    
}
