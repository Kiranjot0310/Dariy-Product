//
//  ViewController.swift
//  DairyFinal
//
//  Created by Kiran Hans on 11/10/17.
//  Copyright © 2017 Kiran Hans. All rights reserved.
//

import UIKit

class ViewController: UIViewController , UITextFieldDelegate {
    @IBOutlet weak var pass: UITextField!
    @IBOutlet weak var uname: UITextField!
    @IBAction func login(_ sender: UIButton) {
        if(uname.text!=="" || pass.text!==""){
            let alert = UIAlertController(title: "Error Message", message: "All Fields are required", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }else{
            var index=""
            let u=MyVar.email
            let p=MyVar.pass
            for i in 0..<u.count{
                if(u[i]==uname.text!){
                    index=String(i)
                    break
                }
            }
            if(index==""){
                let alert = UIAlertController(title: "Error Message", message: "User is Wrong", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }else{
                var ind=Int(index)
                if(p[ind!]==pass.text!){
                     let home:UIViewController = (self.storyboard?.instantiateViewController(withIdentifier: "home") as? Home)!
                    self.navigationController?.pushViewController(home, animated: true)
                }else{
                    let alert = UIAlertController(title: "Error Message", message: "Password is wrong", preferredStyle: UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    
    @IBAction func reset(_ sender: UIButton) {
        uname.text=""
        pass.text=""
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        if(MyVar.statusLogin==0){
            MyVar.statusLogin=1
            MyVar.name=["kiran","komal"]
            MyVar.email=["e1","e2"]
            MyVar.mobile=["9988776655","9786543210"]
            MyVar.pass=["123","123"]
            
        }
        navigationItem.hidesBackButton=true
   
    
    self.uname.delegate=self
    self.pass.delegate=self
}
func textFieldShouldReturn(_ textField: UITextField) -> Bool {
    
    self.view.endEditing(true)
    return true
}

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
        
    }
    
}


