//
//  Home.swift
//  DairyFinal
//
//  Created by Kiran Hans on 11/10/17.
//  Copyright © 2017 Kiran Hans. All rights reserved.
//

import Foundation
import UIKit

class Register: UIViewController,UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        self.view.endEditing(true)
        return true
    }
    
    @IBOutlet weak var mob: UITextField!
    @IBOutlet weak var pass: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var name: UITextField!
    @IBAction func add(_ sender: UIButton) {
        if(name.text!=="" || pass.text!=="" || email.text!=="" || mob.text!==""){
            let alert = UIAlertController(title: "Error Message", message: "All Fields are required", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }else{
            MyVar.email.append(email.text!)
            MyVar.name.append(name.text!)
            MyVar.pass.append(pass.text!)
            MyVar.mobile.append(mob.text!)
            let alert = UIAlertController(title: "Successful Message", message: "Data Added", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    @IBAction func reset(_ sender: UIButton) {
        email.text=""
        name.text=""
        mob.text=""
        pass.text=""
        
    
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.mob.delegate=self
        self.pass.delegate=self
        self.email.delegate=self
        self.name.delegate=self
    
    }
}


