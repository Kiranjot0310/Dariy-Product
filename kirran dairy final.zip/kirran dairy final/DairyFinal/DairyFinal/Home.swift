//
//  Home.swift
//  DairyFinal
//
//  Created by Kiran Hans on 11/10/17.
//  Copyright © 2017 Kiran Hans. All rights reserved.

import UIKit
import MapKit
import CoreLocation


class Home: UIViewController,MKMapViewDelegate
{
   
    
    @IBOutlet weak var mapView: MKMapView!
    var isInitialLoad = true;
    var firstCountryIndex = -1;
    var secondCountryIndex = -1;
    let locations = [
        ["title": "Select Country",    "latitude": 0.0, "longitude": 0.0],
        ["title": "Brampton", "latitude": 43.6833 , "longitude": -79.7666],
        ["title": "Toronto",     "latitude": 43.6532, "longitude":-79.3832],
        ["title": "Mississauga",     "latitude":43.5890 , "longitude":-79.6441]
    ]
    func initializeData(){
        
        self.mapView.delegate = self;
        self.addMarkersToMap();
    }
    
    //TODO:- Calculating Distance between two countries.
    
    func addMarkersToMap(){
        print("\(locations[0])");
        var i = 0;
        var pinColor = UIColor.blue;
        for location in locations {
            switch i {
            case 0:
                pinColor = UIColor.blue;
                break;
            case 1:
                pinColor = UIColor.yellow;
                break;
            case 2:
                pinColor = UIColor.green;
                break;
            case 3:
                pinColor = UIColor.gray;
                break;
                
            default:
                pinColor = UIColor.orange;
                break;
            }
            i += 1;
            let annotation = ColorPointAnnotation();
            annotation.pinColor = pinColor;
            //let annotation = MKPointAnnotation();
            annotation.title = location["title"] as? String
            annotation.coordinate = CLLocationCoordinate2D(latitude: location["latitude"] as! Double, longitude: location["longitude"] as! Double)
            if(annotation.title != "Select Country"){
                mapView.addAnnotation(annotation);
            }
            isInitialLoad = true;
        }
    }
    
    func mapView(_ map: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        if let pin = annotation as? ColorPointAnnotation {
            let identifier = "pinAnnotation"
            if let view = map.dequeueReusableAnnotationView(withIdentifier: identifier) as? MKPinAnnotationView {
                view.pinTintColor = pin.pinColor
                return view
            } else {
                let view = MKPinAnnotationView(annotation: annotation, reuseIdentifier: identifier)
                view.canShowCallout = true
                view.pinTintColor = pin.pinColor
                return view
            }
        }
        return nil
    }
    
    override func viewDidLayoutSubviews() {
        if isInitialLoad {
            self.fitMapViewToAnnotaionList(annotations: mapView.annotations as! [MKPointAnnotation]);
            isInitialLoad = false;
        }
    }
    
    func fitMapViewToAnnotaionList(annotations: [MKPointAnnotation]) -> Void {
        let mapEdgePadding = UIEdgeInsets(top: 20, left: 20, bottom: 20, right: 20)
        var zoomRect:MKMapRect = MKMapRectNull
        
        for index in 0..<annotations.count {
            let annotation = annotations[index]
            let aPoint:MKMapPoint = MKMapPointForCoordinate(annotation.coordinate)
            let rect:MKMapRect = MKMapRectMake(aPoint.x, aPoint.y, 0.1, 0.1)
            
            if MKMapRectIsNull(zoomRect) {
                zoomRect = rect
            } else {
                zoomRect = MKMapRectUnion(zoomRect, rect)
            }
        }
        mapView.setVisibleMapRect(zoomRect, edgePadding: mapEdgePadding, animated: true)
        self.mapView.showAnnotations(self.mapView.annotations, animated: true)
    }
    
    //TODO: - Display Error Message
    func displayErrorMessage(errorTitle : String, errorMessage : String){
        let alertController = UIAlertController(title: errorTitle, message:
            errorMessage, preferredStyle: UIAlertControllerStyle.alert)
        alertController.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default,handler: nil))
        self.present(alertController, animated: true, completion: nil)
    }
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    @IBAction func ont(_ sender: UIButton) {
        MyVar.dairy=2
        let pro:UIViewController = (self.storyboard?.instantiateViewController(withIdentifier: "product") as? Products)!
        self.navigationController?.pushViewController(pro, animated: true)
        
        
        
    }
    
    @IBAction func hans(_ sender: UIButton) {
        MyVar.dairy=1
        let pro:UIViewController = (self.storyboard?.instantiateViewController(withIdentifier: "product") as? Products)!
        self.navigationController?.pushViewController(pro, animated: true)
    }
    @IBAction func logout(_ sender: UIButton) {
         let log:UIViewController = (self.storyboard?.instantiateViewController(withIdentifier: "viewc") as? ViewController)!
        self.navigationController?.pushViewController(log, animated: true)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        MyVar.myOrderPrice=[String]()
        MyVar.myOrderPrice=[String]()
        if(MyVar.checkStatus==1){
            MyVar.checkStatus=0
            let alert = UIAlertController(title: "Congrates!!!", message: "Order is done", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        self.initializeData();
        navigationItem.hidesBackButton=true
    }
}
class ColorPointAnnotation: MKPointAnnotation {
    var pinColor: UIColor
    
    override init() {
        self.pinColor = .purple;
        super.init()
    }
}



