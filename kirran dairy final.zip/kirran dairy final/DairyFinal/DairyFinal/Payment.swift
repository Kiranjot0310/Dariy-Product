//
//  Home.swift
//  DairyFinal
//
//  Created by Kiran Hans on 11/10/17.
//  Copyright © 2017 Kiran Hans. All rights reserved.
//

import Foundation
import UIKit

class Payment: UIViewController,UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        self.view.endEditing(true)
        return true
    }
  
    @IBOutlet weak var code: UITextField!
    
    @IBOutlet weak var ccnum: UITextField!
    
    @IBAction func done(_ sender: UIButton) {
        if(code.text!=="" || ccnum.text!==""){
            let alert = UIAlertController(title: "Error Message", message: "All Fields are required", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }else{
            MyVar.checkStatus=1
            let home:UIViewController = (self.storyboard?.instantiateViewController(withIdentifier: "home") as? Home)!
            self.navigationController?.pushViewController(home, animated: true)
            let alert = UIAlertController(title: "Congrats!!!", message: "Order Is done", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Want to Buy more poducts Or Logout", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.hidesBackButton=true
        self.code.delegate=self
        self.ccnum.delegate=self
    }
    
    }


